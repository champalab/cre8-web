# Privacy Policy for Cre8 Facebook Sync Chrome Extension

**Last Updated:** September 14, 2026

## 1. Introduction
**Cre8 Facebook Sync** ("the Extension") is a productivity tool developed for administrators and content managers using the **Cre8 Influencer Platform** (https://cre8.la). The Extension enables secure, one-click synchronization of Facebook viewer session cookies to facilitate video performance and public engagement analytics for influencer marketing campaigns.

We are committed to respecting and protecting your privacy. This Privacy Policy details how data is handled by the Extension.

---

## 2. Information We Access and Collect
The Extension accesses only the minimum data required to perform its single intended function:

- **Facebook Session Cookies:**
  - Specifically: `c_user` (Facebook User ID) and session authentication tokens (`xs`, `datr`, `fr`, `sb`).
  - **No Personal Messages:** The Extension does NOT access, read, or store your private messages, inbox, personal feed, photos, contacts, or notifications.
  - **No Password Access:** The Extension never accesses, handles, or stores your Facebook password.

---

## 3. How We Use the Data
- The session cookies are transmitted directly to the user's authenticated Cre8 platform instance (`https://*.cre8.la` or your dedicated workspace).
- The Cre8 platform uses this viewer session strictly to inspect public metrics (views, likes, comments, shares) of influencer campaign videos and reels.
- **No Third-Party Sharing:** We do NOT sell, rent, trade, or distribute your session cookies or personal data to any third party, advertising network, or data broker.
- **No Tracking:** We do NOT track your browsing history or monitor activity across other websites.

---

## 4. Permissions Justification
- **`cookies` & `*://*.facebook.com/*`:** Required exclusively to read authenticated session cookies from `facebook.com` so the user does not need to manually copy and paste cookies via Developer Tools.
- **`storage`:** Used locally on the user's browser to store local extension UI state and preferences.
- **`https://*.cre8.la/*`:** Required to communicate securely with the Cre8 web application via content scripts.

---

## 5. Data Security
- All communications between the Extension and the Cre8 platform occur over encrypted HTTPS connections.
- Stored session tokens on the Cre8 platform are encrypted at rest using industry-standard AES-256-GCM encryption.

---

## 6. User Control and Revocation
- You can disconnect or revoke the session at any time directly within the Cre8 Web Application (**Social Platforms** > **Facebook viewer** > **Disconnect**).
- You may also invalidate the session immediately by logging out of Facebook in your browser or changing your Facebook account password.
- You can uninstall the Extension at any time via `chrome://extensions`.

---

## 7. Contact Information
If you have questions regarding this Privacy Policy or data security, please contact us:
- **Website:** https://cre8.la
- **Email:** support@cre8.la
