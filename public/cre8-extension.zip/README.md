# Cre8 Facebook Sync - Chrome Extension

Chrome Extension (Manifest V3) ສຳລັບດຶງ Facebook Cookies ແບບ 1-Click ສົ່ງເຂົ້າລະບົບ Cre8 Influencer Platform.

---

## ວິທີຕິດຕັ້ງ (Installation Guide)

1. ເປີດ **Google Chrome** (ຫຼື Edge, Brave)
2. ພິມ `chrome://extensions` ໃສ່ Address bar ແລ້ວກົດ Enter
3. ເປີດສະວິດ **Developer mode** (ຢູ່ມຸມເທິງຂວາ)
4. ກົດປຸ່ມ **Load unpacked** (ຢູ່ມຸມເທິງຊ້າຍ)
5. ເລືອກໂຟນເດີ `cre8-chrome-extension` (ຫຼື ແຕກໄຟລ໌ zip `cre8-extension.zip` ແລ້ວເລືອກໂຟນເດີ)
6. ສຳເລັດ! ຈະເຫັນໄອຄອນ **Cre8 Facebook Sync** ໃນ Extension bar.

---

## ວິທີໃຊ້ງານ 1-Click Sync

1. ເປີດ `facebook.com` ໃນ Browser ແລ້ວ Login ບັນຊີ Facebook Viewer
2. ເຂົ້າລະບົບ Cre8 ໄປທີ່ໜ້າ **ແພລດຟອມໂຊຊຽວ** ➔ ແທັບ **Facebook viewer**
3. ກົດປຸ່ມ **"ເຊື່ອມຕໍ່ Facebook"**
4. ລະບົບຈະກວດພົບ Extension ອັດຕະໂນມັດ ➔ ກົດປຸ່ມ **"🚀 ດຶງ Cookies ແລະ ເຊື່ອມຕໍ່ທັນທີ (1-Click)"**
5. ເຊື່ອມຕໍ່ສຳເລັດ ໂດຍບໍ່ຕ້ອງເປີດ DevTools ຫຼື Copy ຫຍັງເລີຍ!
