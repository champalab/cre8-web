// Cre8 Facebook Sync - Content Script (Injected on Cre8 web app)

(function () {
    // Notify webpage that extension is installed
    function notifyWebpage() {
        window.postMessage(
            {
                type: 'CRE8_EXTENSION_INSTALLED',
                version: '1.0.0',
            },
            '*'
        )
    }

    // Announce immediately and periodically on initial page load
    notifyWebpage()
    setTimeout(notifyWebpage, 500)
    setTimeout(notifyWebpage, 1500)

    // Listen for requests from the webpage
    window.addEventListener('message', (event) => {
        // Only accept messages from the current window
        if (event.source !== window) return

        const data = event.data
        if (!data || typeof data !== 'object') return

        if (data.type === 'CRE8_PING') {
            window.postMessage(
                {
                    type: 'CRE8_PONG',
                    installed: true,
                    version: '1.0.0',
                },
                '*'
            )
            return
        }

        if (data.type === 'CRE8_REQUEST_FB_COOKIES') {
            chrome.runtime.sendMessage({ type: 'CRE8_FETCH_FB_COOKIES' }, (response) => {
                window.postMessage(
                    {
                        type: 'CRE8_RESPONSE_FB_COOKIES',
                        requestId: data.requestId,
                        result: response,
                    },
                    '*'
                )
            })
        }
    })
})()
