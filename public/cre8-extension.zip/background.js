// Cre8 Facebook Sync - Background Service Worker

/**
 * Retrieves Facebook cookies and formats them into a cookie string.
 */
async function getFacebookCookies() {
    try {
        const cookies = await chrome.cookies.getAll({ domain: 'facebook.com' })
        if (!cookies || cookies.length === 0) {
            return {
                success: false,
                error: 'NO_COOKIES_FOUND',
                message: 'No cookies found for facebook.com. Please open facebook.com and log in.',
            }
        }

        const cookieMap = new Map()
        for (const c of cookies) {
            cookieMap.set(c.name, c.value)
        }

        const cUser = cookieMap.get('c_user')
        const xs = cookieMap.get('xs')

        if (!cUser) {
            return {
                success: false,
                error: 'NOT_LOGGED_IN',
                message: 'Not logged into Facebook. c_user cookie not found.',
            }
        }

        if (!xs) {
            return {
                success: false,
                error: 'INCOMPLETE_SESSION',
                message: 'Found c_user but missing xs session cookie.',
                userId: cUser,
            }
        }

        // Format into standard cookie header string
        const formatted = Array.from(cookieMap.entries())
            .map(([name, val]) => `${name}=${val}`)
            .join('; ')

        return {
            success: true,
            cookieString: formatted,
            userId: cUser,
            totalCookies: cookies.length,
        }
    } catch (err) {
        return {
            success: false,
            error: 'COOKIE_FETCH_ERROR',
            message: err.message || 'Failed to query chrome.cookies',
        }
    }
}

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'CRE8_FETCH_FB_COOKIES') {
        getFacebookCookies().then((res) => {
            sendResponse(res)
        })
        return true // Keep sendResponse channel open for async
    }

    if (message.type === 'CRE8_CHECK_EXTENSION_STATUS') {
        sendResponse({
            installed: true,
            version: chrome.runtime.getManifest().version,
        })
        return false
    }
})
