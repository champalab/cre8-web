// Cre8 Facebook Sync - Popup Script

document.addEventListener('DOMContentLoaded', async () => {
    const statusDot = document.getElementById('statusDot')
    const statusText = document.getElementById('statusText')
    const userInfo = document.getElementById('userInfo')
    const userId = document.getElementById('userId')
    const btnSync = document.getElementById('btnSync')
    const btnOpenCre8 = document.getElementById('btnOpenCre8')

    let currentCookies = null

    // Check Facebook status via background service worker
    chrome.runtime.sendMessage({ type: 'CRE8_FETCH_FB_COOKIES' }, (res) => {
        if (!res) {
            statusDot.className = 'status-dot error'
            statusText.textContent = 'Cannot communicate with extension'
            btnSync.disabled = true
            return
        }

        if (res.success) {
            currentCookies = res.cookieString
            statusDot.className = 'status-dot success'
            statusText.textContent = 'Facebook Logged In'
            userInfo.style.display = 'flex'
            userId.textContent = res.userId || 'Unknown'
            btnSync.disabled = false
            btnSync.innerHTML = '<span class="btn-icon">📋</span> Copy Cookies'
        } else {
            statusDot.className = 'status-dot error'
            statusText.textContent = res.message || 'Not Logged In'
            btnSync.disabled = false
            btnSync.innerHTML = '<span class="btn-icon">🔗</span> Open facebook.com to Login'
        }
    })

    btnSync.addEventListener('click', async () => {
        if (currentCookies) {
            await navigator.clipboard.writeText(currentCookies)
            const orig = btnSync.innerHTML
            btnSync.innerHTML = '<span class="btn-icon">✅</span> Copied to Clipboard!'
            setTimeout(() => {
                btnSync.innerHTML = orig
            }, 2000)
        } else {
            chrome.tabs.create({ url: 'https://www.facebook.com' })
        }
    })

    btnOpenCre8.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://cre8.la/app/platforms?tab=viewer' })
    })
})
